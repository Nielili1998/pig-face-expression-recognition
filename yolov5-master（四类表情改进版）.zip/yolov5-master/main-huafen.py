# # --*-- encoding: utf-8 --*--
# # @Author: Koorye
# # @Date:   2022-4-10
# import json
# import os
# from PIL import Image
# from tqdm import tqdm
#
#

import os
import random
import shutil
def moveFile(Txtdir):
        pathDir = os.listdir(Txtdir)    #获取标签列表
        filenumber=len(pathDir)
        rate=0.1    #定义抽取图片的比例
        random_imgnum=int(filenumber*rate) #按照比例从文件夹中取一定数量标签
        sample = random.sample(pathDir, random_imgnum)  #随机选取random_imgnum数量的样本标签
        print (sample)
        for labelname in sample:
            nameimg = os.path.splitext(labelname)[0]
            shutil.move(Txtdir+labelname, Txt_target_dir+labelname)
            shutil.move(Imgdir+nameimg+'.jpg', img_target_dir+nameimg+'.jpg')

        '''
        for imgname in sample:
                #name0 = os.path.join(outdir1,os.path.basename(name))
                nametxt=os.path.splitext(imgname)[0]
                shutil.move(Imgdir+imgname, img_target_dir+imgname)
                shutil.move(Txtdir+nametxt+'.txt', Txt_target_dir+nametxt+'.txt')
        '''
        return


if __name__ == '__main__':

    Imgdir = "./datasets/train/images/"#图像文件夹
    img_target_dir = "./test/images/"#划分目标图像文件夹
    Txtdir = "./datasets/train/labels/"#标签文件夹
    Txt_target_dir="./test/labels/"#划分目标标签文件夹
    #moveFile(Imgdir)
    moveFile(Txtdir)


# root = './datasets/WiderPerson/'
# ann_path_template = 'instances_{}.json'
#
# clses = ['pedestrains', 'riders', 'paritally-visible persons', 'ignore regions', 'crowd']
#
# def get_img_ids(path):
#     with open(path) as f:
#         s = f.readlines()
#         s = list(map(lambda x: x.strip(), s))
#     return s
#
# def get_cats():
#     cats = []
#     for id_, cls in enumerate(tqdm(clses, desc='Getting Categories')):
#         cats.append(dict(
#             id=id_,
#             name=cls,
#         ))
#     return cats
#
# def get_anns(img_ids):
#     anns = []
#     id_ = 0
#
#     for img_id in tqdm(img_ids, desc='Getting Annotations'):
#         with open(os.path.join(root, f'Annotations/{img_id}.jpg.txt')) as f:
#             s = f.readlines()
#             for i in range(len(s)):
#                 if i == 0:
#                     continue
#
#                 line = s[i]
#                 cls_id, x1, y1, x2, y2 = line.strip().split(' ')
#                 cls_id = int(cls_id) - 1
#                 x1, y1, x2, y2 = float(x1), float(y1), float(x2), float(y2)
#                 w, h = x2 - x1, y2 - y1
#
#                 area = w * h
#                 iscrowd = 1 if cls_id == 4 else 0
#                 bbox = [x1, y1, w, h]
#
#                 anns.append(dict(
#                     area=area,
#                     iscrowd=iscrowd,
#                     image_id=int(img_id),
#                     bbox=bbox,
#                     category_id=cls_id,
#                     id=id_,
#                 ))
#
#                 id_ += 1
#
#     return anns
#
# def get_imgs(img_ids):
#     imgs = []
#     for img_id in tqdm(img_ids, desc='Getting Images'):
#         img_name = f'{img_id}.jpg'
#
#         img_path = os.path.join(root, 'Images/', img_name)
#         img = Image.open(img_path)
#         w, h = img.size
#
#         imgs.append(dict(
#             file_name=img_name,
#             height=h,
#             width=w,
#             id=int(img_id)
#         ))
#
#     return imgs
#
# def get_ann_dict(img_ids):
#     cats = get_cats()
#     anns = get_anns(img_ids)
#     imgs = get_imgs(img_ids)
#
#     return dict(
#         images=imgs,
#         annotations=anns,
#         categories=cats,
#     )
#
# def save_ann_file(ann_dict, name, min=False):
#     path = os.path.join(root, 'Annotations/', ann_path_template.format(name))
#     print('Annotation file will be saved to:', path)
#
#     with open(path, 'w') as f:
#         if min:
#             json.dump(ann_dict, f)
#         else:
#             json.dump(ann_dict, f, indent=2)
#
# train_img_ids = get_img_ids(os.path.join(root, 'train.txt'))
# val_img_ids = get_img_ids(os.path.join(root, 'val.txt'))
#
# train_ann = get_ann_dict(train_img_ids)
# val_ann = get_ann_dict(val_img_ids)
#
# save_ann_file(train_ann, 'train')
# save_ann_file(val_ann, 'val')
#
# import os
# from PIL import Image
# import shutil
#
#
# # coding=utf-8
# def check_charset(file_path):
#     import chardet
#     with open(file_path, "rb") as f:
#         data = f.read(4)
#         charset = chardet.detect(data)['encoding']
#     return charset
#
#
# def convert(size, box0, box1, box2, box3):
#     dw = 1. / size[0]
#     dh = 1. / size[1]
#     x = (box0 + box2) / 2 * dw
#     y = (box1 + box3) / 2 * dh
#     w = (box2 - box0) * dw
#     h = (box3 - box1) * dh
#     return (x, y, w, h)
#
#
# if __name__ == '__main__':
#     #/ home / wkg / Downloads / WiderPerson2COCO - main(1) / datasets / WiderPerson
#     outpath_txt = './datasets/WiderPerson/WiderPerson/test/label'
#     # 注意：这里F:\\WiderPerson是你存储文件侧地方，可以替换，后面的不要动
#     outpath_jpg = './datasets/WiderPerson/WiderPerson/test/images'
#     # 注意：这里F:\\WiderPerson是你存储文件侧地方，可以替换，后面的不要动
#     os.makedirs(outpath_txt)
#     os.makedirs(outpath_jpg)
#
#     path = './datasets/WiderPerson/te.txt'
#     with open(path, 'r') as f:
#         img_ids = [x for x in f.read().splitlines()]
#
#     for img_id in img_ids:  # '000040'
#         img_path = './datasets/WiderPerson/Images/' + img_id + '.jpg'
#
#         with Image.open(img_path) as Img:
#             img_size = Img.size
#
#         ans = ''
#
#         label_path = img_path.replace('Images', 'Annotations') + '.txt'
#
#         outpath = outpath_txt + "/" + img_id + '.txt'
#
#         with open(label_path, encoding=check_charset(label_path)) as file:
#             line = file.readline()
#             count = int(line.split('\n')[0])  # 里面行人个数
#             line = file.readline()
#             while line:
#                 cls = int(line.split(' ')[0])
#                 if cls == 1:
#                     # if cls == 1  or cls == 3:
#                     xmin = float(line.split(' ')[1])
#                     ymin = float(line.split(' ')[2])
#                     xmax = float(line.split(' ')[3])
#                     ymax = float(line.split(' ')[4].split('\n')[0])
#                     print(img_size[0], img_size[1], xmin, ymin, xmax, ymax)
#                     bb = convert(img_size, xmin, ymin, xmax, ymax)
#                     ans = ans + '1' + ' ' + ' '.join(str(a) for a in bb) + '\n'
#                 line = file.readline()
#         with open(outpath, 'w') as outfile:
#             outfile.write(ans)
#         # 想保留原文件用copy
#         # shutil.copy(img_path, outpath_o + '\\' + img_id + '.jpg')
#         # 直接移动用这个
#         shutil.move(img_path, outpath_jpg + '/' + img_id + '.jpg')
